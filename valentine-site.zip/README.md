# Valentine site

Simple single-file static site. Open `valentine.html` in a browser or deploy to GitHub Pages.

## Quick publish (using `gh`)

If you have the GitHub CLI (`gh`) installed and authenticated, from this folder run:

```bash
gh repo create my-valentine-site --public --source=. --remote=origin --push
```

Then enable GitHub Pages in repo settings (or it will be published from `gh-pages` branch or `/docs` if configured).

## Manual publish

1. Create a new GitHub repository (via website).
2. Add the remote and push:

```bash
git remote add origin https://github.com/<your-user>/<repo>.git
git branch -M main
git push -u origin main
```

3. In the repository Settings → Pages, choose the `main` branch and `/ (root)`, then save. The site will be available at `https://<your-user>.github.io/<repo>/valentine.html`.